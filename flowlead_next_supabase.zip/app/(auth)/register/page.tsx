import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";

export default function RegisterPage({ searchParams }: { searchParams: { message?: string } }) {
  async function register(formData: FormData) {
    "use server";
    const supabase = createClient();

    const studioName = String(formData.get("studioName") || "").trim();
    const fullName = String(formData.get("fullName") || "").trim();
    const email = String(formData.get("email") || "").trim();
    const password = String(formData.get("password") || "");

    if (password.length < 8) {
      redirect("/register?message=" + encodeURIComponent("Пароль должен содержать минимум 8 символов."));
    }

    const { data, error } = await supabase.auth.signUp({ email, password });
    if (error || !data.user) {
      redirect(`/register?message=${encodeURIComponent(error?.message || "Не удалось зарегистрироваться")}`);
    }

    const { data: studio, error: studioError } = await supabase.from("studios").insert({ name: studioName }).select("id").single();
    if (studioError || !studio) {
      redirect(`/register?message=${encodeURIComponent(studioError?.message || "Не удалось создать студию")}`);
    }

    const { error: profileError } = await supabase.from("profiles").insert({
      id: data.user.id,
      studio_id: studio.id,
      full_name: fullName,
      email
    });

    if (profileError) {
      redirect(`/register?message=${encodeURIComponent(profileError.message)}`);
    }

    redirect("/dashboard");
  }

  return (
    <div className="card authCard">
      <div className="tabs">
        <Link href="/login" className="tab" style={{ textAlign: "center" }}>Вход</Link>
        <button className="tab tabActive">Регистрация</button>
      </div>
      <h2 className="authTitle">Создайте рабочее пространство</h2>
      <p className="authSubtitle">Регистрация занимает меньше минуты. После входа можно сразу добавлять лиды и назначать ответственных.</p>
      <form action={register}>
        <div className="field">
          <label className="label">Название студии</label>
          <input className="input" name="studioName" placeholder="Fractal Studio" required />
        </div>
        <div className="grid-2">
          <div className="field">
            <label className="label">Имя</label>
            <input className="input" name="fullName" placeholder="Даврон" required />
          </div>
          <div className="field">
            <label className="label">Email</label>
            <input className="input" type="email" name="email" placeholder="you@studio.ru" required />
          </div>
        </div>
        <div className="field">
          <label className="label">Пароль</label>
          <input className="input" type="password" name="password" placeholder="Минимум 8 символов" required />
        </div>
        <button className="button button-primary" type="submit" style={{ width: "100%", marginTop: 6 }}>Создать аккаунт</button>
      </form>
      {searchParams.message ? <div className="error">{searchParams.message}</div> : null}
    </div>
  );
}
