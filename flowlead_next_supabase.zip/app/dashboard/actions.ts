"use server";

import { createClient } from "@/lib/supabase/server";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";

export async function createLead(formData: FormData) {
  const supabase = createClient();
  const payload = {
    studio_id: String(formData.get("studio_id")),
    company_name: String(formData.get("company_name")),
    contact_name: String(formData.get("contact_name")),
    phone: String(formData.get("phone") || ""),
    source: String(formData.get("source")),
    status: String(formData.get("status")),
    responsible: String(formData.get("responsible")),
    budget: String(formData.get("budget") || ""),
    next_step_date: String(formData.get("next_step_date") || "") || null,
    note: String(formData.get("note") || ""),
    created_by: String(formData.get("created_by"))
  };
  const { error } = await supabase.from("leads").insert(payload);
  if (error) redirect("/dashboard?message=" + encodeURIComponent(error.message));
  revalidatePath("/dashboard");
}

export async function updateLead(formData: FormData) {
  const supabase = createClient();
  const id = String(formData.get("id"));
  const payload = {
    company_name: String(formData.get("company_name")),
    contact_name: String(formData.get("contact_name")),
    phone: String(formData.get("phone") || ""),
    source: String(formData.get("source")),
    status: String(formData.get("status")),
    responsible: String(formData.get("responsible")),
    budget: String(formData.get("budget") || ""),
    next_step_date: String(formData.get("next_step_date") || "") || null,
    note: String(formData.get("note") || "")
  };
  const { error } = await supabase.from("leads").update(payload).eq("id", id);
  if (error) redirect("/dashboard?message=" + encodeURIComponent(error.message));
  revalidatePath("/dashboard");
}

export async function deleteLead(formData: FormData) {
  const supabase = createClient();
  const id = String(formData.get("id"));
  const { error } = await supabase.from("leads").delete().eq("id", id);
  if (error) redirect("/dashboard?message=" + encodeURIComponent(error.message));
  revalidatePath("/dashboard");
}
