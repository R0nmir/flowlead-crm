create extension if not exists pgcrypto;

create table if not exists public.studios (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  studio_id uuid not null references public.studios(id) on delete cascade,
  full_name text not null,
  email text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.leads (
  id uuid primary key default gen_random_uuid(),
  studio_id uuid not null references public.studios(id) on delete cascade,
  company_name text not null,
  contact_name text not null,
  phone text,
  source text not null default 'Сайт',
  status text not null default 'new' check (status in ('new','in_progress','won','lost')),
  responsible text not null,
  budget text,
  next_step_date date,
  note text,
  created_by uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists leads_set_updated_at on public.leads;
create trigger leads_set_updated_at
before update on public.leads
for each row execute procedure public.set_updated_at();

alter table public.studios enable row level security;
alter table public.profiles enable row level security;
alter table public.leads enable row level security;

create policy "profiles_select_own" on public.profiles for select using (auth.uid() = id);
create policy "profiles_insert_own" on public.profiles for insert with check (auth.uid() = id);
create policy "profiles_update_own" on public.profiles for update using (auth.uid() = id);

create policy "studios_select_by_profile" on public.studios for select using (
  exists(select 1 from public.profiles p where p.id = auth.uid() and p.studio_id = studios.id)
);
create policy "studios_insert_authenticated" on public.studios for insert with check (auth.uid() is not null);

create policy "leads_select_by_studio" on public.leads for select using (
  exists(select 1 from public.profiles p where p.id = auth.uid() and p.studio_id = leads.studio_id)
);
create policy "leads_insert_by_studio" on public.leads for insert with check (
  exists(select 1 from public.profiles p where p.id = auth.uid() and p.studio_id = leads.studio_id and p.id = leads.created_by)
);
create policy "leads_update_by_studio" on public.leads for update using (
  exists(select 1 from public.profiles p where p.id = auth.uid() and p.studio_id = leads.studio_id)
);
create policy "leads_delete_by_studio" on public.leads for delete using (
  exists(select 1 from public.profiles p where p.id = auth.uid() and p.studio_id = leads.studio_id)
);
