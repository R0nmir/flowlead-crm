export function Logo() {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 14, fontWeight: 800 }}>
      <div
        style={{
          width: 42,
          height: 42,
          borderRadius: 14,
          background: "linear-gradient(135deg,#7c9cff,#5eead4)",
          boxShadow: "0 10px 28px rgba(124,156,255,.28)",
          position: "relative"
        }}
      >
        <span style={{ position: "absolute", left: 12, top: 12, width: 18, height: 4, borderRadius: 999, background: "#fff" }} />
        <span style={{ position: "absolute", right: 8, bottom: 8, width: 10, height: 10, borderRadius: 999, background: "#fff" }} />
      </div>
      <div>
        <div>FlowLead CRM</div>
        <div className="small">Лёгкая CRM для маленьких студий</div>
      </div>
    </div>
  );
}
