import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "FlowLead CRM",
  description: "Лёгкая CRM для маленьких студий"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ru">
      <body>{children}</body>
    </html>
  );
}
