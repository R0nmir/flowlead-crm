import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";

export default function LoginPage({ searchParams }: { searchParams: { message?: string } }) {
  async function login(formData: FormData) {
    "use server";
    const supabase = createClient();
    const email = String(formData.get("email") || "");
    const password = String(formData.get("password") || "");
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) redirect(`/login?message=${encodeURIComponent(error.message)}`);
    redirect("/dashboard");
  }

  return (
    <div className="card authCard">
      <div className="tabs">
        <button className="tab tabActive">Вход</button>
        <Link href="/register" className="tab" style={{ textAlign: "center" }}>Регистрация</Link>
      </div>
      <h2 className="authTitle">С возвращением</h2>
      <p className="authSubtitle">Войдите в систему и продолжите работу с лидами вашей студии.</p>
      <form action={login}>
        <div className="field">
          <label className="label">Email</label>
          <input className="input" type="email" name="email" placeholder="you@studio.ru" required />
        </div>
        <div className="field">
          <label className="label">Пароль</label>
          <input className="input" type="password" name="password" placeholder="••••••••" required />
        </div>
        <button className="button button-primary" type="submit" style={{ width: "100%", marginTop: 6 }}>Войти</button>
      </form>
      {searchParams.message ? <div className="error">{searchParams.message}</div> : null}
    </div>
  );
}
