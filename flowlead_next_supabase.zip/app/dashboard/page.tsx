import { DashboardShell } from "@/components/dashboard-shell";
import { LeadForm } from "@/components/lead-form";
import { StatusBadge } from "@/components/status-badge";
import { createClient } from "@/lib/supabase/server";
import { Lead } from "@/lib/types";
import { createLead, deleteLead, updateLead } from "./actions";

function isOverdue(lead: Lead) {
  if (!lead.next_step_date || lead.status === "won" || lead.status === "lost") return false;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return new Date(lead.next_step_date) < today;
}

function formatDate(value: string | null) {
  if (!value) return "—";
  return new Date(value).toLocaleDateString("ru-RU", { day: "2-digit", month: "short" });
}

export default async function DashboardPage({
  searchParams
}: {
  searchParams: { q?: string; source?: string; status?: string; responsible?: string; edit?: string; message?: string };
}) {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;

  const { data: profile } = await supabase.from("profiles").select("id, studio_id, full_name, email, studios(name)").eq("id", user.id).single();
  const { data: leadsData } = await supabase.from("leads").select("*").eq("studio_id", profile?.studio_id).order("created_at", { ascending: false });
  const leads = (leadsData || []) as Lead[];

  const q = (searchParams.q || "").toLowerCase();
  const source = searchParams.source || "all";
  const status = searchParams.status || "all";
  const responsible = searchParams.responsible || "all";

  const filtered = leads.filter((lead) => {
    const qMatch = !q || [lead.company_name, lead.contact_name, lead.phone || "", lead.note || ""].join(" ").toLowerCase().includes(q);
    return qMatch && (source === "all" || lead.source === source) && (status === "all" || lead.status === status) && (responsible === "all" || lead.responsible === responsible);
  });

  const counts = {
    total: leads.length,
    new: leads.filter((x) => x.status === "new").length,
    inProgress: leads.filter((x) => x.status === "in_progress").length,
    overdue: leads.filter((x) => isOverdue(x)).length
  };

  const sourceStats = Object.entries(leads.reduce<Record<string, number>>((acc, lead) => {
    acc[lead.source] = (acc[lead.source] || 0) + 1;
    return acc;
  }, {}));

  const editLead = searchParams.edit ? leads.find((l) => l.id === searchParams.edit) : undefined;
  const responsibles = [...new Set(leads.map((l) => l.responsible))];
  const studioName = (profile?.studios as any)?.name || "Studio";

  return (
    <DashboardShell userName={profile?.full_name || ""} studioName={studioName} email={profile?.email || ""}>
      <div className="container">
        <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 16, marginBottom: 24, flexWrap: "wrap" }}>
          <div>
            <h1 style={{ margin: 0, fontSize: 34, letterSpacing: -1 }}>Лиды и контроль заявок</h1>
            <p className="small" style={{ marginTop: 8 }}>Лёгкая CRM для маленьких студий: видеть поток заявок, статусы и просрочки на одном экране.</p>
          </div>
        </div>

        {searchParams.message ? (
          <div style={{ padding: "12px 14px", borderRadius: 12, background: "rgba(255,123,123,.09)", border: "1px solid rgba(255,123,123,.28)", marginBottom: 18 }}>
            {searchParams.message}
          </div>
        ) : null}

        <section style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 16, marginBottom: 22 }}>
          <div className="card" style={{ padding: 18 }}><div className="badge badge-new">Всего лидов</div><div style={{ fontSize: 34, fontWeight: 800, marginTop: 18 }}>{counts.total}</div><div className="small">в рабочем пространстве</div></div>
          <div className="card" style={{ padding: 18 }}><div className="badge badge-new">Новые</div><div style={{ fontSize: 34, fontWeight: 800, marginTop: 18 }}>{counts.new}</div><div className="small">требуют быстрой реакции</div></div>
          <div className="card" style={{ padding: 18 }}><div className="badge badge-progress">В работе</div><div style={{ fontSize: 34, fontWeight: 800, marginTop: 18 }}>{counts.inProgress}</div><div className="small">активные сделки</div></div>
          <div className="card" style={{ padding: 18 }}><div className="badge">Просрочено</div><div style={{ fontSize: 34, fontWeight: 800, marginTop: 18 }}>{counts.overdue}</div><div className="small">нужно проверить сегодня</div></div>
        </section>

        <div style={{ display: "grid", gridTemplateColumns: "1.1fr .9fr", gap: 18 }}>
          <div className="card" style={{ padding: 22 }}>
            <div style={{ marginBottom: 18 }}>
              <h2 style={{ margin: 0, fontSize: 20 }}>Реестр лидов</h2>
              <div className="small" style={{ marginTop: 6 }}>Список, фильтры и быстрые действия без перегруженных сущностей.</div>
            </div>

            <form style={{ display: "grid", gridTemplateColumns: "1.3fr .8fr .8fr .9fr", gap: 12, marginBottom: 14 }}>
              <input className="input" name="q" placeholder="Поиск по компании, контакту, телефону" defaultValue={searchParams.q || ""} />
              <select className="select" name="source" defaultValue={source}>
                <option value="all">Все источники</option>
                {["Сайт", "Telegram", "WhatsApp", "Avito", "Звонок", "Рекомендация"].map((item) => <option key={item}>{item}</option>)}
              </select>
              <select className="select" name="status" defaultValue={status}>
                <option value="all">Все статусы</option>
                <option value="new">Новая</option>
                <option value="in_progress">В работе</option>
                <option value="won">Закрыта</option>
                <option value="lost">Потеряна</option>
              </select>
              <select className="select" name="responsible" defaultValue={responsible}>
                <option value="all">Все ответственные</option>
                {responsibles.map((item) => <option key={item}>{item}</option>)}
              </select>
              <button className="button button-secondary">Применить фильтры</button>
            </form>

            <div style={{ overflow: "auto" }}>
              <table style={{ width: "100%", borderCollapse: "separate", borderSpacing: "0 10px" }}>
                <thead>
                  <tr style={{ color: "#8f98b6", fontSize: 12, textAlign: "left" }}>
                    <th style={{ padding: "0 12px 8px" }}>Лид</th>
                    <th style={{ padding: "0 12px 8px" }}>Источник</th>
                    <th style={{ padding: "0 12px 8px" }}>Статус</th>
                    <th style={{ padding: "0 12px 8px" }}>Ответственный</th>
                    <th style={{ padding: "0 12px 8px" }}>Срок</th>
                    <th style={{ padding: "0 12px 8px" }}>Бюджет</th>
                    <th style={{ padding: "0 12px 8px" }}>Действия</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((lead) => (
                    <tr key={lead.id}>
                      <td style={cellLeft}><div style={{ fontWeight: 700 }}>{lead.company_name}</div><div className="small" style={{ marginTop: 5 }}>{lead.contact_name} · {lead.phone || "—"}</div></td>
                      <td style={cell}>{lead.source}</td>
                      <td style={cell}><StatusBadge status={lead.status} /></td>
                      <td style={cell}>{lead.responsible}</td>
                      <td style={cell}><div>{formatDate(lead.next_step_date)}</div><div className="small" style={{ marginTop: 4, color: isOverdue(lead) ? "#ffb0b0" : "#98a3c2" }}>{isOverdue(lead) ? "Просрочено" : "без нарушения"}</div></td>
                      <td style={cell}>{lead.budget || "—"}</td>
                      <td style={cellRight}>
                        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                          <a className="button button-secondary" href={`/dashboard?edit=${lead.id}`} style={{ padding: "10px 12px" }}>Редактировать</a>
                          <form action={deleteLead}>
                            <input type="hidden" name="id" value={lead.id} />
                            <button className="button button-secondary" style={{ padding: "10px 12px" }}>Удалить</button>
                          </form>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {!filtered.length ? <div style={{ padding: 24, border: "1px dashed rgba(255,255,255,.12)", borderRadius: 18, textAlign: "center", color: "#98a3c2" }}>Лидов по выбранным фильтрам нет.</div> : null}
            </div>
          </div>

          <div style={{ display: "grid", gap: 18 }}>
            <div className="card" style={{ padding: 22 }}>
              <h2 style={{ margin: 0, fontSize: 20 }}>Новый лид</h2>
              <div className="small" style={{ marginTop: 6, marginBottom: 18 }}>Минимум полей, которые реально нужны маленькой студии для контроля заявки.</div>
              <LeadForm action={editLead ? updateLead : createLead} lead={editLead} responsibleDefault={profile?.full_name || ""} studioId={profile?.studio_id || ""} userId={profile?.id || ""} />
            </div>

            <div className="card" style={{ padding: 22 }}>
              <h2 style={{ margin: 0, fontSize: 20 }}>Статистика по источникам</h2>
              <div className="small" style={{ marginTop: 6, marginBottom: 18 }}>Базовая аналитика без BI и сложных отчётов.</div>
              <div style={{ display: "grid", gap: 12 }}>
                {sourceStats.length ? sourceStats.map(([name, count]) => (
                  <div key={name} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "14px 16px", borderRadius: 16, background: "rgba(255,255,255,.03)", border: "1px solid rgba(255,255,255,.08)" }}>
                    <div><div style={{ fontWeight: 700 }}>{name}</div><div className="small">Лиды из канала</div></div>
                    <strong>{count}</strong>
                  </div>
                )) : <div className="small">Пока нет данных по источникам.</div>}
              </div>
            </div>
          </div>
        </div>
      </div>
    </DashboardShell>
  );
}

const baseCell = { background: "rgba(255,255,255,.03)", padding: "14px 12px", borderTop: "1px solid rgba(255,255,255,.08)", borderBottom: "1px solid rgba(255,255,255,.08)" } as const;
const cellLeft = { ...baseCell, borderLeft: "1px solid rgba(255,255,255,.08)", borderRadius: "14px 0 0 14px" };
const cell = baseCell;
const cellRight = { ...baseCell, borderRight: "1px solid rgba(255,255,255,.08)", borderRadius: "0 14px 14px 0" };
