import "./auth-layout.css";
import { Logo } from "@/components/logo";

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="auth-shell">
      <div className="auth-left">
        <Logo />
        <div className="hero">
          <div className="eyebrow"><span className="eyebrowDot" />Быстрый старт без хаоса</div>
          <h1>Контроль заявок, который не выглядит как комбайн.</h1>
          <p>Добавляйте лиды, назначайте ответственных, отслеживайте статус сделок и не теряйте заявки из сайта, Telegram, Avito и мессенджеров.</p>
          <div className="heroCards">
            <div className="miniCard"><div className="miniCardKpi">15 мин</div><div className="miniCardLabel">на запуск и первую настройку</div></div>
            <div className="miniCard"><div className="miniCardKpi">4 статуса</div><div className="miniCardLabel">без лишних сущностей и перегруза</div></div>
            <div className="miniCard"><div className="miniCardKpi">1 экран</div><div className="miniCardLabel">чтобы видеть все активные лиды</div></div>
          </div>
        </div>
        <div className="small">После запуска сможешь показать MVP команде и клиентам.</div>
      </div>
      <div className="authRight">{children}</div>
    </div>
  );
}
