# FlowLead CRM — Next.js + Supabase

Стартовая нормальная версия лёгкой CRM для маленьких студий:

- email/password авторизация через Supabase Auth
- workspace = одна студия
- CRUD по лидам
- статусы: new / in_progress / won / lost
- ответственный, источник, бюджет, срок следующего шага
- дашборд со статистикой
- RLS в базе: пользователь видит только лиды своей студии

## Быстрый запуск

```bash
npm install
cp .env.example .env.local
# заполните ключи Supabase
npm run dev
```

## Что сделать в Supabase
1. Создать проект
2. Включить Email auth
3. Выполнить SQL из `supabase/schema.sql`

## Что уже внутри
- /login
- /register
- /dashboard
- middleware auth
- server actions для leads

## Что доделать для продакшна
- invite members / роли
- email confirm / reset password
- уведомления
- интеграции
- аудит действий
- тесты
