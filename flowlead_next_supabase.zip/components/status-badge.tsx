import { LeadStatus } from "@/lib/types";

export function StatusBadge({ status }: { status: LeadStatus }) {
  if (status === "new") return <span className="badge badge-new">Новая</span>;
  if (status === "in_progress") return <span className="badge badge-progress">В работе</span>;
  if (status === "won") return <span className="badge badge-won">Закрыта</span>;
  return <span className="badge badge-lost">Потеряна</span>;
}
