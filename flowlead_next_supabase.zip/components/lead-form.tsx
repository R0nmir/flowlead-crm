import { Lead } from "@/lib/types";

export function LeadForm({
  action, lead, responsibleDefault, studioId, userId
}: {
  action: (formData: FormData) => Promise<void>;
  lead?: Lead;
  responsibleDefault: string;
  studioId: string;
  userId: string;
}) {
  return (
    <form action={action}>
      <input type="hidden" name="studio_id" value={studioId} />
      <input type="hidden" name="created_by" value={userId} />
      {lead ? <input type="hidden" name="id" value={lead.id} /> : null}

      <div className="grid-2">
        <div><label className="label">Компания / проект</label><input className="input" name="company_name" defaultValue={lead?.company_name} required /></div>
        <div><label className="label">Контактное лицо</label><input className="input" name="contact_name" defaultValue={lead?.contact_name} required /></div>
      </div>

      <div className="grid-2" style={{ marginTop: 14 }}>
        <div><label className="label">Телефон</label><input className="input" name="phone" defaultValue={lead?.phone || ""} /></div>
        <div>
          <label className="label">Источник</label>
          <select className="select" name="source" defaultValue={lead?.source || "Сайт"}>
            {["Сайт", "Telegram", "WhatsApp", "Avito", "Звонок", "Рекомендация"].map((item) => <option key={item}>{item}</option>)}
          </select>
        </div>
      </div>

      <div className="grid-2" style={{ marginTop: 14 }}>
        <div>
          <label className="label">Статус</label>
          <select className="select" name="status" defaultValue={lead?.status || "new"}>
            <option value="new">Новая</option>
            <option value="in_progress">В работе</option>
            <option value="won">Закрыта</option>
            <option value="lost">Потеряна</option>
          </select>
        </div>
        <div><label className="label">Ответственный</label><input className="input" name="responsible" defaultValue={lead?.responsible || responsibleDefault} required /></div>
      </div>

      <div className="grid-2" style={{ marginTop: 14 }}>
        <div><label className="label">Бюджет</label><input className="input" name="budget" defaultValue={lead?.budget || ""} placeholder="например 90 000 ₽" /></div>
        <div><label className="label">Дедлайн следующего шага</label><input className="input" type="date" name="next_step_date" defaultValue={lead?.next_step_date || ""} /></div>
      </div>

      <div style={{ marginTop: 14 }}>
        <label className="label">Комментарий</label>
        <textarea className="textarea" name="note" defaultValue={lead?.note || ""} />
      </div>

      <button className="button button-primary" style={{ marginTop: 18 }}>
        {lead ? "Сохранить изменения" : "Добавить лид"}
      </button>
    </form>
  );
}
