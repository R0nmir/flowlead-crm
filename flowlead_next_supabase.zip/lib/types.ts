export type LeadStatus = "new" | "in_progress" | "won" | "lost";

export interface Lead {
  id: string;
  studio_id: string;
  company_name: string;
  contact_name: string;
  phone: string | null;
  source: string;
  status: LeadStatus;
  responsible: string;
  budget: string | null;
  next_step_date: string | null;
  note: string | null;
  created_by: string;
  created_at: string;
  updated_at: string;
}
