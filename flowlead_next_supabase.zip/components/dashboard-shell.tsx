import { ReactNode } from "react";
import { Logo } from "./logo";

export function DashboardShell({
  userName, studioName, email, children
}: {
  userName: string; studioName: string; email: string; children: ReactNode;
}) {
  return (
    <div style={{ minHeight: "100vh", display: "grid", gridTemplateColumns: "280px 1fr" }}>
      <aside style={{ borderRight: "1px solid rgba(255,255,255,.08)", background: "rgba(7,11,22,.55)", backdropFilter: "blur(16px)", padding: 24, position: "sticky", top: 0, height: "100vh" }}>
        <Logo />
        <div style={{ marginTop: 26 }}>
          <div className="small" style={{ textTransform: "uppercase", letterSpacing: ".12em", marginBottom: 10 }}>Навигация</div>
          <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 14px", borderRadius: 14, background: "rgba(255,255,255,.05)" }}>
            <div style={{ width: 18, height: 18, borderRadius: 6, background: "#22305f" }} />
            <span>Дашборд</span>
          </div>
        </div>
        <div style={{ marginTop: 26 }}>
          <div className="small" style={{ textTransform: "uppercase", letterSpacing: ".12em", marginBottom: 10 }}>Памятка MVP</div>
          <div className="small" style={{ lineHeight: 1.7 }}>Только нужные сущности: лид, статус, ответственный, срок и источник. Без лишних воронок и перегруза.</div>
        </div>
        <form action="/auth/sign-out" method="post" style={{ position: "absolute", left: 18, right: 18, bottom: 18 }}>
          <div className="card" style={{ padding: 14, borderRadius: 18 }}>
            <div className="badge">Workspace</div>
            <div style={{ marginTop: 12, fontWeight: 800 }}>{studioName}</div>
            <div className="small" style={{ marginTop: 6 }}>{userName} · {email}</div>
            <button className="button button-secondary" style={{ width: "100%", marginTop: 14 }}>Выйти</button>
          </div>
        </form>
      </aside>
      <main>{children}</main>
    </div>
  );
}
